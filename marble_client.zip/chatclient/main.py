import json
import os
from threading import Thread
from time import sleep
from client import connect
import validators
import ipaddress
from server import run_server
import socket
import uuid

#Getting IP so that people know what to put in other people's PCs
client_ip = socket.gethostbyname(socket.gethostname())

#Reading config.json
with open("config.json", "r+") as conf_file:
    config = json.loads(conf_file.read())

if config["username"] == "User":
    print("Looks like you didn't set your username. Please type a username here:")
    newun = input(">")
    with open("config.json", "w+") as conf_file:
        config["username"] = newun
        config = json.dumps(config)
        conf_file.write(config)
    with open("config.json", "r+") as conf_file:
        config = json.loads(conf_file.read())

#A function to make text with a cool border
def border(text):
    lines = text.splitlines()
    width = max(len(s) for s in lines)
    res = ['*' + '-' * width + '*']
    for s in lines:
        res.append('|' + (s + ' ' * width)[:width] + '|')
    res.append('*' + '-' * width + '*')
    return '\n'.join(res)

#Checking if a string is a valid IP
def is_ip(ip):
    try:
        ipaddress.ip_address(ip)
        return True
    except ValueError:
        return False
    except:
        return False

#Clearing the screen
def clear():
    if os.name == "nt":
        os.system("cls")
    else:
        os.system("clear")
        
#The menu loop
while True:
    clear()
    print("Marble")
    print("Version " + config["version"])
    print(border("""
[1] - Connect to a server
[2] - Host a server
[3] - Quit
"""))
    option = input(">")
    #Connecting to a server
    if option == "1":
        clear()
        print("Please type the server address:")
        addr = input(">")
        if not ":" in addr:
            addr = addr + ":65530"
        ip, port = addr.split(":")
        if validators.url(ip) or is_ip(ip) or ip == "localhost":
            try:
                connect(ip, int(port), config["username"])
            except ConnectionRefusedError:
                print("That chat doesn't exist or is full.")
                sleep(1)
                clear()
        else:
            print("Invalid address.")
            clear()
    elif option == "2":
        clear()
        print("Please type a port (leave blank for default)")
        port = input(">")
        if port == "":
            port = "65530"
        clear()
        code = str(uuid.uuid1())
        print("Running server, the address (on your local network) is " + client_ip + ":" + port + "")
        t = Thread(target=run_server, args=(port,code))
        # make the thread daemon so it ends whenever the main thread ends
        t.daemon = True
        # start the thread
        t.start()
        connect("localhost", port, config["username"])
        clear()
        s = socket.socket()
        s.connect(("localhost", int(port)))
        s.send(json.dumps({
        "type": "close",
        "code": code
        }).encode())
        try:
            s.close()
        except OSError:
            pass
        sleep(1)
        clear()
    elif option == "3":
        break
    else:
        print("Invalid option!")
        sleep(1)
        clear()
