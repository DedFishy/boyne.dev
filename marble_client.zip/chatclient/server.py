import socket
from threading import Thread
import json
import colorama
import sys
from time import sleep

clients = {}
client_sockets = set()
# create a TCP socket
s = socket.socket()
running = True

with open("config.json", "r+") as conf_file:
    config = json.loads(conf_file.read())

def listen_for_client(cs, quitcode):
        """
        This function keep listening for a message from `cs` socket
        Whenever a message is received, broadcast it to all other connected clients
        """
        global client_sockets, s, running
        while running:
            try:
                # keep listening for a message from `cs` socket
                msg = cs.recv(1024).decode()
            except Exception as e:
                # client no longer connected
                # remove it from the set
                try:
                    client_sockets.remove(cs)
                except:
                    pass
            else:
                msg = json.loads(msg)
                uid = msg['uid'] + "-" + msg['name']
                if msg["type"] == "message":
                    message = "{color}[{name}]{color_reset} {message}".replace("{color}", clients[uid]["color"]).replace("{name}", msg["name"]).replace("{message}", msg["message"]).replace("{color_reset}", colorama.Style.RESET_ALL)
                elif msg["type"] == "quit":
                    
                    for client_socket in client_sockets:
                        try:
                            client_socket.send((msg["name"] + " left the chat.").encode())
                        except UnboundLocalError:
                            pass
                        except ConnectionResetError:
                            pass
                elif msg["type"] == "close":
                    if str(msg["code"]) == str(quitcode):
                        running = False
                        for cs in client_sockets:
                            cs.close()
                        # close server socket
                        s.close()
                        print("Closed server.")
                elif msg["type"] == "client_info":
                    try:
                        clients[uid]
                        for client_socket in client_sockets:
                            try:
                                client_socket.send((msg["name"] + " joined the chat, but they have the same ID and username as " + clients[uid] + ", so they will be treated as the same person.").encode())
                            except UnboundLocalError:
                                pass
                    except KeyError:
                        clients[uid] = {"name": msg["name"], "color": msg["color"]}
                        for client_socket in client_sockets:
                            try:
                                client_socket.send((msg["name"] + " joined the chat.").encode())
                            except UnboundLocalError:
                                pass
            # iterate over all connected sockets
            if msg["type"] == "message":
                for client_socket in client_sockets:
                    # and send the message
                    client_socket.send(message.encode())

def run_server(SERVER_PORT=65530, quitcode="quitcode"):
    global clients, client_sockets, s, running
    running = True
    # server's IP address
    s = socket.socket()
    SERVER_HOST = "0.0.0.0"
    SERVER_PORT = 65530 # port we want to use
    separator_token = "<SEP>" # we will use this to separate the client name & message
    # initialize list/set of all connected client's sockets
    # make the port as reusable port
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    # bind the socket to the address we specified
    s.bind((SERVER_HOST, SERVER_PORT))
    # listen for upcoming connections
    s.listen(10)

    while running:
        # we keep listening for new connections all the time
        client_socket, client_address = s.accept()
        # add the new connected client to connected sockets
        client_sockets.add(client_socket)
        # start a new thread that listens for each client's messages
        t = Thread(target=listen_for_client, args=(client_socket,quitcode))
        # make the thread daemon so it ends whenever the main thread ends
        t.daemon = True
        # start the thread
        t.start()
    # close client sockets
    for cs in client_sockets:
        cs.close()
    # close server socket
    s.close()
