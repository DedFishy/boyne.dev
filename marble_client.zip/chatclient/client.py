import socket
import random
from threading import Thread
from datetime import datetime
from colorama import Fore, init, Back
import json
from time import sleep
import uuid

# init colors
init()

s = socket.socket()

def listen_for_messages():
    global s
    while True:
        try:
            message = s.recv(1024).decode()
            failed = False
        except:
            failed = True
        if not failed:
            print(message)
        else:
            break

def connect(SERVER_HOST="localhost", SERVER_PORT=65530, name="User"):
    global s
    #UID generator. DON'T MESS WITH IT. It could cause issues in servers if you do.
    uid = str(uuid.uuid1())
    s = socket.socket()
    if SERVER_PORT == "":
        SERVER_PORT = 65530
    try:
        SERVER_PORT = int(SERVER_PORT)
    except:
        print("Invalid port, defaulting to 65530")
        SERVER_PORT = 65530
    separator_token = "<SEP>" # we will use this to separate the client name & message

    print(f"Connecting to the server...")
    # connect to the server
    s.connect((SERVER_HOST, SERVER_PORT))
    print("Connected. Type a message and press enter to send it. Use !help for a list of commands.")

    # make a thread that listens for messages to this client & print them
    t = Thread(target=listen_for_messages)
    # make the thread daemon so it ends whenever the main thread ends
    t.daemon = True
    # start the thread
    t.start()

    # set the available colors
    colors = [Fore.BLUE, Fore.CYAN, Fore.GREEN, Fore.LIGHTBLACK_EX, 
        Fore.LIGHTBLUE_EX, Fore.LIGHTCYAN_EX, Fore.LIGHTGREEN_EX, 
        Fore.LIGHTMAGENTA_EX, Fore.LIGHTRED_EX, Fore.LIGHTWHITE_EX, 
        Fore.LIGHTYELLOW_EX, Fore.MAGENTA, Fore.RED, Fore.WHITE, Fore.YELLOW
    ]

    # choose a random color for the client
    client_color = random.choice(colors)
    
    s.send(json.dumps({
        "uid": uid,
        "name": name,
        "type": "client_info",
        "color": client_color
        }).encode())

    while True:
        # input message we want to send to the server
        to_send = input("")
        cmd = None
        if to_send.startswith("!"):
            # a way to exit the program
            cmd = to_send
            cmd = cmd.replace("!", "", 1)
            if cmd.lower().startswith("help"):
                print("""
    !quit - Quits the chat
    """)
            if cmd.lower().startswith("quit"):
                s.send(json.dumps({"uid": uid, "type":"quit", "name":name}).encode())
                break
        # add the datetime, name & the color of the sender
        date_now = datetime.now().strftime('%Y-%m-%d %H:%M:%S') 
        to_send = json.dumps({
            "uid": uid,
            "message": to_send,
            "name": name,
            "type": "message"
            })
        # finally, send the message
        if cmd == None:
            try:
                s.send(to_send.encode())
            except ConnectionResetError:
                print("You were disconnected from the server.")
                sleep(1)
                break

    # close the socket
    s.close()
